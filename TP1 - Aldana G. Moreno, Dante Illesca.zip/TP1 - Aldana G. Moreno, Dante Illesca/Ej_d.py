simbolos = ['¿','?','.',',',';',':','¡','!','(',')','"']
dpalabras = dict()
def contar_palabras(texto):
    numpalabras = 0
    with open('archivos_texto/parrafo.txt','r', encoding="utf8") as texto:
        for linea in texto:
            for simbolo in simbolos:
                linea = linea.replace(simbolo,' ')
            palabras = linea.split()
            for palabra in palabras:
                numpalabras += 1
                dpalabras[palabra] = dpalabras.get(palabra , 0) + 1
        print('El texto contiene %s palabras' %numpalabras)
    return max(dpalabras, key=dpalabras.get)


print("La palabra que más se repite es:", contar_palabras("archivos_texto/parrafo.txt"))