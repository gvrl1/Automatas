def ipv4_valido(ipv4):
    with open("archivos_texto/ipv4.txt", "r") as ipv4:
        for linea in ipv4:
            if linea.find(".") or linea.isdigit() and linea <= 255 and linea >= 0:
                return True
            else:
                return False
            

print(ipv4_valido("archivos_texto/ipv4.txt"))