def url_valido(url):
    with open("archivos_texto/url.txt", "r") as url:
        for linea in url:
            if linea.find("http://") or linea.find("https://") or linea.find("www."):
                return True
            elif linea.find(".com") or linea.find(".ar") or linea.find(".org") or linea.find(".net") or linea.find(".edu") or linea.find(".info") or linea.find("/") or linea.find("?"):
                return True
            else:
                return False
            
print(url_valido("archivos_texto/url.txt"))