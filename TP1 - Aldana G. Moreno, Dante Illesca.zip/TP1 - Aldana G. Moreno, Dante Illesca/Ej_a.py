def es_mail_valido(mails):
    with open("archivos_texto/mails.txt", "r") as mails:
        for linea in mails:
            if linea[0].isalpha():
                return True
            elif linea.isalnum() and linea.find("." or "_" or "-"):
                return True
            else:
                return False
            
print(es_mail_valido("archivos_texto/mails.txt"))