import re

pattern = r"""^https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)$"""
with open("archivos_texto/urls.txt","r") as urls:
    for i in urls:
        match = re.fullmatch(pattern,i.strip())
        if match is not None:
            print(i,"is valid")
        else:
            print(i,"is not valid")