import re

pattern = r"""(\b25[0-5]|\b2[0-4][0-9]|\b[01]?[0-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}"""
with open("archivos_texto/direcciones.txt","r") as ipv4:
    for i in ipv4:
        match = re.fullmatch(pattern,i.strip())
        if match is not None:
            print(i,"is valid")
        else:
            print(i,"is not valid")