import re

pattern = r"""[a-zA-Z\_\-0-9\.]+\@[a-zA-Z\_\-0-9]+\.(com|net|org|gob|edu|um|global|padron|caritas)\.(ar|bo|br|hk|ec)?"""
with open("archivos_texto/mails.txt","r") as emails:
    for i in emails:
        match = re.fullmatch(pattern,i.strip())
        if match is not None:
            print(i,"is valid")
        else:
            print(i,"is not valid")